#ifndef __GAMELAYER_H__
#define __GAMELAYER_H__

#include "cocos2d.h"
#include "Background.h"
#include "BasicEnemy.h"
#include "Player.h"

class GameLayer : public cocos2d::Layer
{

private:
	int _numEnemies;
	int _enemyIndex;
	cocos2d::Size _visibleSize;

	Background* _bg;
	Player* _player;
	cocos2d::Vector<BasicEnemy*> _enemyPool;

	void awakeEnemy();
	void checkCollisions();

public:

    static cocos2d::Scene* createScene();

    virtual bool init();

	void update(float dt);
    
	CREATE_FUNC(GameLayer);
};

#endif // __GAMELAYER_H__
