#include "BasicEnemy.h"
#include "Player.h"

USING_NS_CC;

BasicEnemy::BasicEnemy() :_speed(100), _numBullets(10), _bulletIndex(0), _initialiced(false)
{
}



bool BasicEnemy::init(){
	if (!Sprite::init())
	{
		return false;
	}

	for (int i = 0; i < _numBullets; i++){
		_bulletPool.pushBack(Bullet::createEnemyBullet());
	}

	_currentAnimation = IDLE;
	createIdleAnimation();

	createExplosionAnimation();

	runAction(_idleAnimation);
	scheduleShoot();
	scheduleUpdate();
	return true;
}

void BasicEnemy::scheduleShoot(){
	DelayTime *delayAction = DelayTime::create(1.5f);

	CallFunc *callSelectorAction = CallFunc::create(CC_CALLBACK_0(BasicEnemy::shoot, this));
	auto shootSequence = Sequence::create(delayAction, callSelectorAction, NULL);

	_shoot = RepeatForever::create(shootSequence);
	_shoot->setTag(SHOOT_TAG);
	_shoot->retain();

	runAction(_shoot);
}

void BasicEnemy::setTarget(Player* target) {
	_target = target;
	for (int i = 0; i < _numBullets; i++){
		_bulletPool.at(i)->setEnemyTarget(_target);
	}
}

void BasicEnemy::shoot(){
	_bulletIndex = _bulletIndex % _numBullets;
	auto bullet = _bulletPool.at(_bulletIndex);
	bullet->setAnchorPoint(Point(0.5, 1));
	if (!bullet->isVisible()){
		bullet->setPosition(getPositionX(), getPositionY() - getBoundingBox().size.height*0.5);
		bullet->setVisible(true);
	}
	_bulletIndex++;
}

void BasicEnemy::setCurrentAnimation(Animations anim){
	if (_currentAnimation == anim) return;
	_currentAnimation = anim;
	if (_currentAnimation == IDLE){
		stopActionByTag(EXPLOSION);
		runAction(_idleAnimation);
	}
	if (_currentAnimation == EXPLOSION){
		stopActionByTag(IDLE);
		runAction(_explosionAnimation);
	}
}

void BasicEnemy::setParent(Node* parent){
	Sprite::setParent(parent);
	if (!_initialiced){
		for (int i = 0; i < _numBullets; i++){
			getParent()->addChild(_bulletPool.at(i));
		}
		_initialiced = true;
	}

}

void BasicEnemy::createIdleAnimation(){
	Vector<SpriteFrame*> animFrames;
	auto acc = 0;
	for (int i = 0; i < 4; i++){
		auto frame = SpriteFrame::create("animacion_enemigo.png", Rect(acc, 0, 50, 50));
		acc += 50;
		animFrames.pushBack(frame);
	}

	this->setSpriteFrame(animFrames.at(0));

	auto animation = Animation::createWithSpriteFrames(animFrames, 0.25f);

	auto animate = Animate::create(animation);

	_idleAnimation = RepeatForever::create(animate);

	_idleAnimation->setTag(BasicEnemy::Animations::IDLE);

	_idleAnimation->retain();
}

void BasicEnemy::createExplosionAnimation(){
	Vector<SpriteFrame*> animFrames;
	auto acc = 0;
	for (int i = 0; i < 4; i++){
		auto frame = SpriteFrame::create("animacion_enemigo_explotar.png", Rect(acc, 0, 50, 50));
		acc += 50;
		animFrames.pushBack(frame);
	}

	auto animation = Animation::createWithSpriteFrames(animFrames, 0.10f);

	_explosionAnimation = Animate::create(animation);;

	_explosionAnimation->setTag(BasicEnemy::Animations::EXPLOSION);

	_explosionAnimation->retain();
}

void BasicEnemy::setVisible(bool visible){
	Sprite::setVisible(visible);
	if (visible){
		runAction(_shoot);
	}
	else{
		stopActionByTag(SHOOT_TAG);
	}
}



void BasicEnemy::update(float dt){
	if (!isVisible()) return;

	if (_currentAnimation == EXPLOSION){
		stopActionByTag(SHOOT_TAG);
		if (_explosionAnimation->isDone() && isVisible()){
			setVisible(false);
		}
		return;
	}
	//para abajo
	setAnchorPoint(Point(0.5, 1));
	setPosition(getPositionX(), getPositionY() - _speed*dt);
	if (getPositionY() < 0){
		setVisible(false);
	}
}





