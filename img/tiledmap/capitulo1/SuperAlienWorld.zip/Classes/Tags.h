#pragma once

#define PLAYER_CONTACT_MASK 0xFFFFFFFF
#define GROUND_TAG 0
#define WINNING_AREA 1
#define PLAYER_TAG 2
#define ENEMY_TAG 3
#define WALL_TAG 4