

#ifndef __PLAYERBULLETx3_H__
#define __PLAYERBULLETx3_H__

#include "PlayerBullet.h"


class PlayerBulletx3 :public PlayerBullet
{
public:
	CREATE_FUNC(PlayerBulletx3);
	virtual bool init();

};
#endif //__PLAYERBULLETx3_H__